'use strict';

module.exports = {
  metadata: () => ({
    name: 'oracle.sample.QuoteOfDay',
    properties: {
      name: {
        required: true,
        type: 'string'
      },
    },
    supportedActions: []
  }),

  invoke: (conversation, done) => {
    // perform conversation tasks.
    const {usr} = conversation.properties();
    conversation.logger().info("Opening quote generator");
    
    var quotes = require("./src/Quotes.json");
    var quote = quotes[Math.floor(Math.random() * quotes.length)];

    var messageModel = conversation.MessageModel();
    conversation.logger().info("User name: "+usr);
    var payload = "Hi " + usr + ". Here's a quote for you.";
    var actions = [];

    var textResponse = messageModel.textConversationMessage(payload, actions);
    conversation.reply(textResponse);
    
    payload = "'"+quote.quote+"'\n\n Quote by: "+quote.origin;
    conversation.logger().info("Quote found: "+payload);
    textResponse = messageModel.textConversationMessage(payload, actions);
    conversation.reply(textResponse);
    conversation.transition();
    done();
  }
};
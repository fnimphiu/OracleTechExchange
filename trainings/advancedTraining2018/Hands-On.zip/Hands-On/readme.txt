README.TXT
==========

Hands-On instructions are available online: https://bots-training.github.io/index.html 

